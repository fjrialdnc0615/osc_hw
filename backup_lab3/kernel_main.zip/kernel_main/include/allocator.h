#include <stddef.h>
void* simple_malloc(size_t size);
