int mbox_call(unsigned char ch);
void get_board_revision();
void get_size_and_memory_address();
